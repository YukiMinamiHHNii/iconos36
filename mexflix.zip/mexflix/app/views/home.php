<main class="Main">
  <section class="container">
    <div class="row">
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
      <article class="col s12 m6 l4 xl3">
        <?php require './app/components/card.php'; ?>
      </article>
    </div>
  </section>
</main>
