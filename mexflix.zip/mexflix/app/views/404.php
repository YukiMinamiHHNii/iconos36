<main>
  <h2><?php echo $_GET['meta_title']; ?></h2>
  <p><?php echo $_GET['meta_description']; ?></p>
</main>
