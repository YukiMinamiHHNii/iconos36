<ul id="slide-profile" class="side-nav">
    <li><div class="user-view">
        <div class="background">
          <img src="https://jonmircha.com/img/jonmircha-edcamp-2017.jpg">
        </div>
        <a href="#!user"><img class="circle" src="https://jonmircha.com/img/jonmircha.jpg"></a>
        <a href="#!name"><span class="white-text name">Jon MirCha</span></a>
        <a href="#!email"><span class="white-text email">jonmircha@gmail.com</span></a>
      </div></li>
    <li><a href="#!"><i class="material-icons">cloud</i>First Link With Icon</a></li>
    <li><a href="#!">Second Link</a></li>
    <li><div class="divider"></div></li>
    <li><a class="subheader">Subheader</a></li>
    <li><a class="waves-effect" href="#!">Third Link With Waves</a></li>
  </ul>
