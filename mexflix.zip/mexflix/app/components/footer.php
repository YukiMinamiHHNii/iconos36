<footer class="Footer  page-footer">
  <div class="container">
    <div class="row valign-wrapper">
      <div class="col s4">
        <h4>Mexflix</h4>
      </div>
      <div class="col s7 offset-s1">
        <p class="right-align">
          Películas y series, cualquier parecido con Netflix es mera coincidencia.
        </p>
      </div>
    </div>
  </div>
</footer>
