<nav class="SocialMedia">
  <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
  <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
  <a href="#" target="_blank"><i class="fab fa-youtube"></i></a>
  <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
  <a href="#" target="_blank"><i class="fab fa-linkedin"></i></a>
  <a href="#" target="_blank"><i class="fab fa-whatsapp"></i></a>
  <a href="#" target="_blank"><i class="fab fa-github"></i></a>
</nav>
