    <div class="fixed-action-btn horizontal click-to-toggle">
      <a class="btn-floating btn-large red">
        <i class="material-icons">menu</i>
      </a>
      <ul>
        <li><a class="btn-floating red"><i class="material-icons">home</i></a></li>
        <li><a class="btn-floating red"><i class="material-icons">movie</i></a></li>
        <li><a class="btn-floating red"><i class="material-icons">live_tv</i></a></li>
        <li><a href="#modal-login" class="btn-floating red modal-trigger"><i class="material-icons">lock</i></a></li>
        <li><a data-activates="slide-profile" class="btn-floating red button-collapse"><i class="material-icons">more_vert</i></a></li>
        <li><a class="btn-floating red"><i class="material-icons">exit_to_app</i></a></li>
      </ul>
    </div>
