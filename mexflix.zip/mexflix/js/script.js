((c, d, w, n, $) => {
  d.addEventListener('DOMContentLoaded', e => {
    $('.modal').modal()
    $('.button-collapse').sideNav()
  })
})(console.log, document, window, navigator, jQuery);
